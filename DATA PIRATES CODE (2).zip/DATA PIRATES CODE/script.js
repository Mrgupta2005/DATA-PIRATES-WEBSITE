<script>
const quizData = [
{
question: 'Which of the following materials can typically be recycled?',
options: ['styrofoam', 'glass', 'plastic bags', 'paper towel'],
answer: 'glass',
},
{
question: 'How should plastic bottles be disposed of for recycling',
options: ['throw in trash', 'rinsed and placed in the recycling bin with the cap on', 'composed', 'burned for energy'],
answer: 'rinsed and placed in the recycling bin with the cap on',
},
{
question: 'Whats the proper way to dispose of glass bottles',
options: ['composed', 'throw them in trash', 'rinsed and placed in the recycling bin with the cap on', 'none'],
answer: 'rinsed and placed in the recycling bin with the cap on',
},
{
question: 'can paper towels be recycled',
options: ['yes', 'both', 'no', 'none of above'],
answer: 'no',
},
{
question: 'What should you do with used cooking oil?',
options: [
  'pour it down the drain',
  'compost it',
  'recycle it ',
  'dispose of it in sealed containers in the trash',
],
answer: 'dispose of it in sealed containers in the trash',
},
{
question: 'which of the following is typically not recyclable',
options: ['aluminium foil', 'cardboard', 'plastic bag', 'paper'],
answer: 'plastic bag',
},
{
question: 'how should paper with ink on it be disposed of for recycling',
options: [
  'burned',
  'composted',
  'thrown in the trash',
  'recycled',
],
answer: 'recycled',
},
{
question: 'can you recycle pizza boxes with grease stains',
options: ['yes', 'no', 'both', 'none of these'],
answer: 'no',
},
{
question: 'what the best way to dispose of old electronics ',
options: [
  'recycle them at designated e-waste recycling centers ',
  'thrown them in the regular trash ',
  'donate them to charity',
  'bury them in the backyard ',
],
answer: 'recycle them at designated e-waste recycling centers .',
},
{
question: 'can you recycle plastic wrap ',
options: ['yes', 'no', 'none of these', 'both'],
answer: 'no',
},
];

const quizContainer = document.getElementById('quiz');
const resultContainer = document.getElementById('result');
const submitButton = document.getElementById('submit');
const retryButton = document.getElementById('retry');
const showAnswerButton = document.getElementById('showAnswer');

let currentQuestion = 0;
let score = 0;
let incorrectAnswers = [];

function shuffleArray(array) {
for (let i = array.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[array[i], array[j]] = [array[j], array[i]];
}
}

function displayQuestion() {
const questionData = quizData[currentQuestion];

const questionElement = document.createElement('div');
questionElement.className = 'question';
questionElement.innerHTML = questionData.question;

const optionsElement = document.createElement('div');
optionsElement.className = 'options';

const shuffledOptions = [...questionData.options];
shuffleArray(shuffledOptions);

for (let i = 0; i < shuffledOptions.length; i++) {
const option = document.createElement('label');
option.className = 'option';

const radio = document.createElement('input');
radio.type = 'radio';
radio.name = 'quiz';
radio.value = shuffledOptions[i];

const optionText = document.createTextNode(shuffledOptions[i]);

option.appendChild(radio);
option.appendChild(optionText);
optionsElement.appendChild(option);
}

quizContainer.innerHTML = '';
quizContainer.appendChild(questionElement);
quizContainer.appendChild(optionsElement);
}

function checkAnswer() {
const selectedOption = document.querySelector('input[name="quiz"]:checked');
if (selectedOption) {
const answer = selectedOption.value;
if (answer === quizData[currentQuestion].answer) {
  score++;
} else {
  incorrectAnswers.push({
    question: quizData[currentQuestion].question,
    incorrectAnswer: answer,
    correctAnswer: quizData[currentQuestion].answer,
  });
}
currentQuestion++;
selectedOption.checked = false;
if (currentQuestion < quizData.length) {
  displayQuestion();
} else {
  displayResult();
}
}
}

function displayResult() {
quizContainer.style.display = 'none';
submitButton.style.display = 'none';
retryButton.style.display = 'inline-block';
showAnswerButton.style.display = 'inline-block';
resultContainer.innerHTML = 'Your Scored ' + score + 'out of'  +  quizData.length + '!';
}

function retryQuiz() {
currentQuestion = 0;
score = 0;
incorrectAnswers = [];
quizContainer.style.display = 'block';
submitButton.style.display = 'inline-block';
retryButton.style.display = 'none';
showAnswerButton.style.display = 'none';
resultContainer.innerHTML = '';
displayQuestion();
}

function showAnswer() {
quizContainer.style.display = 'none';
submitButton.style.display = 'none';
retryButton.style.display = 'inline-block';
showAnswerButton.style.display = 'none';

let incorrectAnswersHtml = '';
for (let i = 0; i < incorrectAnswers.length; i++) {
incorrectAnswersHtml += `
  <p>
    <strong>Question:</strong> ${incorrectAnswers[i].question}<br>
    <strong>Your Answer:</strong> ${incorrectAnswers[i].incorrectAnswer}<br>
    <strong>Correct Answer:</strong> ${incorrectAnswers[i].correctAnswer}
  </p>
`;
}

resultContainer.innerHTML = `
<p>You scored ${score} out of ${quizData.length}!</p>
<p>Incorrect Answers:</p>
${incorrectAnswersHtml}
`;
}

submitButton.addEventListener('click', checkAnswer);
retryButton.addEventListener('click', retryQuiz);
showAnswerButton.addEventListener('click', showAnswer);

displayQuestion();